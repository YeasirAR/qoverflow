const Auth = () => {
    return (
        <div>
            <h1>Auth</h1>
        </div>
    )
}

export default Auth