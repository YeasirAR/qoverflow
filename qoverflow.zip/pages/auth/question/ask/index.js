
const AskQuestion = () => {
    return (
        <div>
            <h1>Ask Question</h1>
        </div>
    )
}

export default AskQuestion