const Tags = () => {
    return (
        <div>
            <h1>Tags</h1>
        </div>
    )
}

export default Tags