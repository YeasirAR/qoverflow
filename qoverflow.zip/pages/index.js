import HomePage from '@/components/homepage/homepage'
import Contact from '../components/about/Contact'
export default function Example() {
  return (
    <div>
    <header>
      <title>qOverflow</title>
    </header>
      <HomePage />
    </div>
  )
}

