import Navbar from '../../components/navbar/navbar'
import Contact from '../../components/about/Contact'

const contactPage = () => {
  return (
    <div>
    <header>
      <title>qOverflow</title>
    </header>
      <Contact />
    </div>
  )
}
export default contactPage;

