
const ViewQuestion = () => {
    return (
        <div>
            <h1>View Question</h1>
        </div>
    )
}

export default ViewQuestion